// src/config.ts
// 针对博主特定的数据
export const ADMIN_USER = {
  nickname: "ddg",
  email: "djjd15846@gmail.com",
  website: "https://ddgdd.232132.xyz",
  avatar: "https://ddgdd.232132.xyz/ddgdd.webp",
};

// 你不希望用户使用的名称与邮箱
export const SENSITIVE_USERS = ["ddg", "DDG",  "admin", "博主", "djjd15846@gmail.com"];
